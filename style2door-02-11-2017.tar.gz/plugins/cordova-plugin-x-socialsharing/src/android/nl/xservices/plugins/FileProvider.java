package nl.xservices.plugins;


public class FileProvider extends android.support.v4.content.FileProvider {
}