package plugin.google.maps;

public interface AsyncLoadImageInterface {
  public void onPostExecute(AsyncLoadImage.AsyncLoadImageResult result) ;
}
